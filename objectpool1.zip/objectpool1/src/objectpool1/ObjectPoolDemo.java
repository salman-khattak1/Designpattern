/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objectpool1;

import java.sql.SQLException;

/**
 *
 * @author test
 */
public class ObjectPoolDemo {

 public static final String CREATE_SCHEMA1 = "CREATE TABLE CUSTOMER1 (ID NUMBER, FNAME VARCHAR(100), "
   + "LNAME VARCHAR(100))";

 public static final String CREATE_SCHEMA2 = "CREATE TABLE CUSTOMER2 (ID NUMBER, FNAME VARCHAR(100), "
   + "LNAME VARCHAR(100))";

 public static final String DELETE_SCHEMA_SQL = "DROP TABLE CUSTOMERS";

 public static void main(String args[]) throws SQLException {

  String driver = "com.mysql.jdbc.Driver";
  // Create the ConnectionPool:
  JDBCConnectionPool pool = new JDBCConnectionPool(
    driver,
    "jdbc:mysql://localhost:3306/demo?createDatabaseIfNotExist=true",
    "root", "root");

  // Create the ConnectionPool:
  pool = new JDBCConnectionPool(
    driver,
    "jdbc:mysql://localhost:3306/demo?createDatabaseIfNotExist=true",
    "root", "root");

  // Get a connection:
  final Connection connection = pool.checkOut();
  System.out.println(connection);
  // Use the connection
  Statement statement = connection.createStatement();
  statement.execute(CREATE_SCHEMA1);
  // Return the connection:
  pool.checkIn(connection);

 }
}